<?php
App::uses('AppModel', 'Model');
/**
 * RefereesPayment Model
 *
 */
class RefereesPayment extends AppModel {

}
