<?php
App::uses('AppModel', 'Model');
/**
 * Purchace Model
 *
 */
class Purchace extends AppModel {

}
