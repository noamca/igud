<?php
App::uses('AppModel', 'Model');
/**
 * RefereesLevel Model
 *
 */
class RefereesLevel extends AppModel {
    
    
       public $primaryKey = "level_description"; 
 

}
