<?php
App::uses('AppModel', 'Model');
/**
 * AssociationsHistory Model
 *
 */
class AssociationsHistory extends AppModel {

}
