<?php
App::uses('AppModel', 'Model');
/**
 * RefereesStudy Model
 *
 */
class RefereesStudy extends AppModel {

}
