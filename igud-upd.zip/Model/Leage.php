<?php
App::uses('AppModel', 'Model');
/**
 * Leage Model
 *
 */
class Leage extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';

}
