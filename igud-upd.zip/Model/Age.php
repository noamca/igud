<?php
App::uses('AppModel', 'Model');
/**
 * Age Model
 *
 */
class Age extends AppModel {

}
