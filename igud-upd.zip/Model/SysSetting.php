<?php
App::uses('AppModel', 'Model');
/**
 * SysSetting Model
 *
 */
class SysSetting extends AppModel {

}
