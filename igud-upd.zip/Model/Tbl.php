<?php
App::uses('AppModel', 'Model');
/**
 * Tbl Model
 *
 */
class Tbl extends AppModel {

}
