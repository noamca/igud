<?php
App::uses('AppModel', 'Model');
/**
 * AthletsMedicalTest Model
 *
 */
class AthletsMedicalTest extends AppModel {

}
