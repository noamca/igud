<?php
App::uses('AppModel', 'Model');
/**
 * Remark Model
 *
 */
class Remark extends AppModel {

}
