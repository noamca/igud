<?php
App::uses('AppModel', 'Model');
/**
 * ModelsFieldsMetaDatum Model
 *
 */
class ModelsFieldsMetaDatum extends AppModel {

}
