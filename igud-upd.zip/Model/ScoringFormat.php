<?php
App::uses('AppModel', 'Model');
/**
 * ScoringFormat Model
 *
 */
class ScoringFormat extends AppModel {

}
