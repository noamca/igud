<?php
App::uses('AppModel', 'Model');
/**
 * Accounting Model
 *
 */
class Accounting extends AppModel {

}
